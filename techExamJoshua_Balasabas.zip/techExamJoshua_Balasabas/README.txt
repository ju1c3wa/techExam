Open VS Code
Open terminal
CD to folder name
Install Cypress Via NPM: npm install cypress --save-dev
Option 1:
Run Cypress Project - npx cypress open
Click E2E testing
Start E2E testing using chrome
Click add to addToCart.cy.js



Option 2:

Run cypress project - 
npx cypress run --record --key 8d3dfaf6-fcb5-4cd7-aafe-3b43947a082e

Copy run url on the terminal
After running the test play video to review test


